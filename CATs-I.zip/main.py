# Graph Conjoint Attention Networks (CATs) for semi-supervised node classification
# Basic parameters: r1 and r2, start&end training id; v1 and v2, start&end validation id;
# t1 and t2, start&end testing id. The default id lists will be load if they are set to 0.

from network_training import Training

train = Training(dataset='cora', lambd=0.01, WL=True, r1=0, r2=0, v1=0, v2=0, t1=0, t2=0)

# some default training samples:
# train = Training(dataset='cite', lambd=0.01, WL=True, r1=0, r2=0, v1=0, v2=0, t1=0, t2=0)
# train = Training(dataset='cora', lambd=0.01, WL=True, r1=0, r2=0, v1=0, v2=0, t1=0, t2=0)
# train = Training(dataset='pubmed', lambd=0.01, WL=True, r1=0, r2=0, v1=0, v2=0, t1=0, t2=0)