import dgl
import time
import random
import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from utils import load_data, accuracy, training_performance
from CATI import CATI_Net


class Training:
    def __init__(self, dataset, lambd, WL, r1, r2, v1, v2, t1, t2):
        self.fastmode = False
        self.log_every = 50
        self.WL = WL
        self.early = False
        self.seed = 1
        self.epochs = 500
        self.lr = 0.005
        self.weight_decay = 5e-4
        self.hidden = 8
        self.nb_heads = 8
        self.dropout = 0.6
        self.alpha = 0.2
        self.patience = 100
        self.lambd = lambd
        self.beta = 1
        self.data = dataset
        self.r1 = r1
        self.r2 = r2
        self.v1 = v1
        self.v2 = v2
        self.t1 = t1
        self.t2 = t2

        random.seed(self.seed)
        np.random.seed(self.seed)
        torch.manual_seed(self.seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed(self.seed)

        # load data
        path = "./data/" + self.data + "/"
        graph, labels, idx_train, idx_val, idx_test, full_idx_test = load_data(path, self.data, self.r1, self.r2,
                                                                               self.v1, self.v2, self.t1, self.t2)

        self.features = graph.ndata['feat']
        self.labels = labels
        self.idx_train = idx_train
        self.idx_val = idx_val
        self.idx_test = idx_test
        self.full_idx_test = full_idx_test

        g1 = dgl.transform.remove_self_loop(graph)

        adj = g1.adjacency_matrix()

        self.adj = adj
        self.model = CATI_Net(nsample=self.features.shape[0],
                              nfeat=self.features.shape[1],
                              nhid=self.hidden,
                              nclass=int(self.labels.max()) + 1,
                              dropout=self.dropout,
                              alpha=self.alpha,
                              nheads=self.nb_heads,
                              WL=self.WL)

        if torch.cuda.is_available():
            device = torch.device("cuda:%d" % 0)
            self.model.cuda()
            self.features = self.features.cuda()
            self.adj = self.adj.cuda()

            self.labels = self.labels.cuda()
            self.idx_train = self.idx_train.cuda()
            self.idx_val = self.idx_val.cuda()
            self.idx_test = self.idx_test.cuda()
            self.full_idx_test = self.full_idx_test.cuda()
            self.graph = graph.to(device)

        self.features, self.adj, self.labels = Variable(self.features), Variable(self.adj), Variable(self.labels)

        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)

        t_total = time.time()
        loss_values = []
        bad_counter = 0
        best = 0
        best_val = 1e9
        best_epoch = 0

        outputpath = "./output/" + self.data + "/"

        print("Network Fitting...")
        for epoch in range(self.epochs):
            loss_values.append(self.train(epoch))

            loss_t, acc_t = self.compute_test(epoch)

            if self.early:
                best_val, best, best_epoch, bad_counter = training_performance(loss_values[-1], best_val, acc_t, best,
                                                                               bad_counter, epoch, best_epoch, True)
                if bad_counter == self.patience:
                    break
            else:
                best_val, best, best_epoch = training_performance(loss_values[-1], best_val, acc_t, best,
                                                                  bad_counter, epoch, best_epoch, False)

        total_time = time.time() - t_total
        print("Optimization Finished!")
        print("Total time elapsed: {:.4f}s".format(total_time))

        print('Semi-supervised node classification accuracy: ' + str(best.data) + ' at epoch '
              + str(best_epoch + 1) + '\n')

        # Recording model settings and experimental results
        f = open(outputpath + self.data + ".log", 'a+')
        f.write('Time: ' + str(time.asctime(time.localtime(time.time()))) + '\n')
        f.write('Dataset: ' + self.data + '\n')
        f.write('Model settings:\n')

        f.write('Methods for learning structure coefficients: ')
        f.write('Matrix factorization,\n')

        f.write('No. attention heads: ' + str(self.nb_heads) + ', ')
        f.write('Dimension of hidden layer: ' + str(self.hidden) + ', ')
        f.write('Learning rate= ' + str(self.lr) + ', ')
        f.write('Lambda= ' + str(self.lambd) + ',\n')
        f.write('WL Filter= ' + str(self.WL) + ',\n')
        f.write('Automatically learning weights of structural and feature attention: ' + str(True) + ',\n')
        f.write('Range of ids of training vertices: ' + str(self.r1) + '-' + str(self.r2) + '\n')
        f.write('Range of ids of validating vertices: ' + str(self.v1) + '-' + str(self.v2) + '\n')
        f.write('Range of ids of testing vertices: ' + str(self.t1) + '-' + str(self.t2) + '\n')
        f.write('Total optimization time: ' + str(total_time) + '\n')
        f.write('Semi-supervised node classification accuracy: ' + str(best.data) + ' at epoch '
                + str(best_epoch + 1) + '\n\n')
        f.close()

    def train(self, epoch):
        t = time.time()
        self.model.train()
        self.optimizer.zero_grad()

        predict, sfeat = self.model(self.graph, self.features)

        node_predict_loss = F.nll_loss(predict[self.idx_train], self.labels[self.idx_train])

        reg = self.compute_reg_grad(self.adj, sfeat)
        structure_loss = self.lambd * torch.sum(torch.mul(sfeat, reg))
        loss_train = node_predict_loss + structure_loss

        acc_train = accuracy(predict[self.idx_train], self.labels[self.idx_train])
        loss_train.backward()
        self.optimizer.step()
        torch.cuda.empty_cache()

        if not self.fastmode:
            # Evaluate validation set performance separately,
            # deactivates dropout during validation run.
            self.model.eval()
            predict, sfeat = self.model(self.graph, self.features)

        loss_val = F.nll_loss(predict[self.idx_val], self.labels[self.idx_val])
        acc_val = accuracy(predict[self.idx_val], self.labels[self.idx_val])

        if (epoch + 1) % self.log_every == 0:
            print('Epoch: {:04d}'.format(epoch + 1),
                  # 'loss_train: {:.4f}'.format(loss_train.data.item()),
                  'loss_train: {:.4f}'.format(node_predict_loss.data.item()),
                  'acc_train: {:.4f}'.format(acc_train.data.item()),
                  'loss_val: {:.4f}'.format(loss_val.data.item()),
                  'acc_val: {:.4f}'.format(acc_val.data.item()),
                  'time: {:.4f}s'.format(time.time() - t))

        return loss_val.data.item()

    def compute_test(self, epoch):
        self.model.eval()

        predict, sfeat = self.model(self.graph, self.features)

        loss_test = F.nll_loss(predict[self.idx_val], self.labels[self.idx_val])
        acc_test = accuracy(predict[self.idx_test], self.labels[self.idx_test])
        if (epoch + 1) % self.log_every == 0:
            print("Test set results:",
                  "loss= {:.4f}".format(loss_test.data),
                  "accuracy= {:.4f}".format(acc_test.data))

        return loss_test, acc_test

    @torch.no_grad()
    def compute_reg_grad(self, fact, para):
        # fact is sparse tensor, para is dense tensor

        # directly compute the gradients w.r.t. external factors to improve the efficiency
        # another possible way is to pre-train the external factors (Eq. (2) or (3) in the manuscript) and combine them
        # with CATs. The performance of such variants might be slightly lower.

        #  matrix factorization is used (Eq. (2) in the manuscript)

        par1 = torch.sparse.mm(fact, para)
        par2 = torch.mm(para.t(), para)
        par2 = torch.mm(para, par2)
        return par2 - par1
